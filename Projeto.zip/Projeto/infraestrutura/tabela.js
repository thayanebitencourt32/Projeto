class Tabelas{
    init(conexao){
        this.conexao= conexao
    }
    criarTabela(){
        const sql='CREATE TABLE Valores (is int NOT NULL AUTO_INCREMENT, NOT NULL,PRIMARY KEY(numbers)'
        this.conexao.query(sql,(erro) =>{
            if(erro){
                console.log(erro)
            }else{
                console.log('criada com sucesso')
            }
        })
    }
}

module.exports  = new Tabelas