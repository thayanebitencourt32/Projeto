
const BASE_URL = require('../URL')

module.exports =  app=>{
 contador = 0;
    while(contador<=10000){
        app.get('BASE_URL'/$contador, (req, res) => res.send('BASE_URL/$contador')) 
  contador+=1;
    }

}


